mem = '1081 Mb'
memSplit = mem.split(" ")
memNum = int(memSplit[0])

print(mem)
print(memSplit)
print(memNum)